extends Resource
class_name DialogAction
@export_enum("add_money","deduct_money","add_life","add_maya_time","start_quest","finish_quest","start_animation","grant_vehicle_access","revoke_vehicle_access","grant_item","revoke_item","close","npc_text") var type := "close" # gdlint:ignore=max-line-length

@export var amount: int = 0
@export var quest_id: String = ""
@export var anim_name: String = ""
@export var loop_count: int = 1
@export var npc_text_id: String = ""
@export var vehicle_id: String = ""
@export var item: ItemData
